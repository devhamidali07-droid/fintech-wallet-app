import React, { useState } from 'react';
import { CreditCard, Home, User, Plus, Wifi, MoreHorizontal } from 'lucide-react';

export default function CardsScreen({ onNavigate }) {
  const [cards, setCards] = useState([
    { id: 1, type: 'Virtual Debit', network: 'Visa', last4: '4242', exp: '12/28', bg: 'from-blue-600 to-indigo-900' }
  ]);

  const handleAddCard = () => {
    const newCard = {
      id: Date.now(),
      type: 'Corporate Credit',
      network: 'Mastercard',
      last4: Math.floor(1000 + Math.random() * 9000).toString(),
      exp: '09/29',
      bg: 'from-fintech-accent to-emerald-900'
    };
    setCards([newCard, ...cards]);
  };

  return (
    <div className="flex min-h-full flex-col text-fintech-text relative">
      <header className="px-6 py-4">
        <h1 className="text-2xl font-bold text-white">My Cards</h1>
        <p className="text-sm text-fintech-muted">Manage your payment methods</p>
      </header>

      <div className="mt-4 flex flex-col gap-6 px-6 overflow-y-auto pb-32">
        {cards.map(card => (
          <div key={card.id} className={`relative h-48 w-full rounded-3xl bg-gradient-to-br ${card.bg} p-6 shadow-xl ring-1 ring-white/20 animate-in fade-in zoom-in duration-300`}>
            <div className="flex justify-between items-start">
              <Wifi size={28} className="rotate-90 text-white/80" />
              <span className="font-bold text-xl italic text-white/90">{card.network}</span>
            </div>
            <div className="mt-8 flex items-center justify-between text-white tracking-widest text-lg font-mono">
              <span>••••</span>
              <span>••••</span>
              <span>••••</span>
              <span>{card.last4}</span>
            </div>
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end">
              <div>
                <p className="text-[10px] text-white/60 uppercase tracking-wider">{card.type}</p>
                <p className="font-semibold text-sm">Hamid Ali</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-white/60 uppercase tracking-wider">EXP</p>
                <p className="font-semibold text-sm">{card.exp}</p>
              </div>
            </div>
          </div>
        ))}

        <button 
          onClick={handleAddCard}
          className="flex h-16 w-full items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-slate-700 bg-fintech-card/50 text-fintech-muted transition hover:border-fintech-accent hover:text-fintech-accent"
        >
          <Plus size={20} /> <span className="font-semibold">Add New Card</span>
        </button>

        <div className="mt-2 space-y-3">
          <div className="flex items-center justify-between rounded-xl bg-fintech-card p-4">
            <span className="text-sm font-medium">Apple Pay Integration</span>
            <div className="h-6 w-11 rounded-full bg-fintech-accent p-1">
              <div className="h-4 w-4 translate-x-5 rounded-full bg-slate-900"></div>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-xl bg-fintech-card p-4">
            <span className="text-sm font-medium">Freeze All Cards</span>
            <div className="h-6 w-11 rounded-full bg-slate-700 p-1">
              <div className="h-4 w-4 rounded-full bg-fintech-muted"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-[40px] w-[359px] flex justify-around border-t border-slate-800 bg-fintech-dark/95 pb-6 pt-4 backdrop-blur-md z-40 rounded-b-[32px]">
        <button onClick={() => onNavigate('dashboard')} className="flex flex-col items-center gap-1 text-fintech-muted hover:text-white transition hover:scale-105"><Home size={24} /><span className="text-[10px]">Home</span></button>
        <button onClick={() => onNavigate('cards')} className="flex flex-col items-center gap-1 text-fintech-accent transition hover:scale-105"><CreditCard size={24} /><span className="text-[10px]">Cards</span></button>
        <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-fintech-muted hover:text-white transition hover:scale-105"><User size={24} /><span className="text-[10px]">Profile</span></button>
      </div>
    </div>
  );
}