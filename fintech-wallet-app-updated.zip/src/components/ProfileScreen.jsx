import React from 'react';
import { Home, CreditCard, User, LogOut, Settings, Shield, HelpCircle, ChevronRight, Bell } from 'lucide-react';

export default function ProfileScreen({ onNavigate, onLogout }) {
  const menuItems = [
    { icon: <Settings size={20} />, title: 'Account Settings', color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { icon: <Shield size={20} />, title: 'Security & Biometrics', color: 'text-fintech-accent', bg: 'bg-fintech-accent/10' },
    { icon: <Bell size={20} />, title: 'Push Notifications', color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { icon: <HelpCircle size={20} />, title: 'Help & Support', color: 'text-orange-400', bg: 'bg-orange-400/10' }
  ];

  return (
    <div className="flex min-h-full flex-col text-fintech-text relative">
      <header className="flex flex-col items-center justify-center pt-8 pb-6">
        <div className="relative">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-fintech-accent to-blue-600 text-3xl font-bold text-white shadow-lg">
            HA
          </div>
          <div className="absolute bottom-0 right-0 h-6 w-6 rounded-full border-4 border-fintech-dark bg-fintech-accent"></div>
        </div>
        <h1 className="mt-4 text-xl font-bold text-white">Hamid Ali</h1>
        <p className="text-sm text-fintech-muted">Enterprise Member</p>
      </header>

      <div className="flex-1 px-6 pb-32">
        <div className="mb-6 flex justify-around rounded-2xl bg-fintech-card p-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-white">12</p>
            <p className="text-[10px] uppercase tracking-wider text-fintech-muted">Transactions</p>
          </div>
          <div className="w-px bg-slate-700"></div>
          <div className="text-center">
            <p className="text-2xl font-bold text-white">3</p>
            <p className="text-[10px] uppercase tracking-wider text-fintech-muted">Active Cards</p>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          {menuItems.map((item, idx) => (
            <button key={idx} className="flex items-center gap-4 rounded-2xl bg-fintech-card p-4 transition hover:bg-slate-700">
              <div className={`flex h-10 w-10 items-center justify-center rounded-full ${item.bg} ${item.color}`}>
                {item.icon}
              </div>
              <span className="font-medium text-white">{item.title}</span>
              <ChevronRight size={18} className="ml-auto text-fintech-muted" />
            </button>
          ))}
          
          <button onClick={onLogout} className="mt-4 flex items-center gap-4 rounded-2xl border border-red-500/20 bg-red-500/10 p-4 transition hover:bg-red-500/20 text-red-500">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-500/20">
              <LogOut size={20} />
            </div>
            <span className="font-bold">Log Out Securely</span>
          </button>
        </div>
      </div>

      <div className="fixed bottom-[40px] w-[359px] flex justify-around border-t border-slate-800 bg-fintech-dark/95 pb-6 pt-4 backdrop-blur-md z-40 rounded-b-[32px]">
        <button onClick={() => onNavigate('dashboard')} className="flex flex-col items-center gap-1 text-fintech-muted hover:text-white transition hover:scale-105"><Home size={24} /><span className="text-[10px]">Home</span></button>
        <button onClick={() => onNavigate('cards')} className="flex flex-col items-center gap-1 text-fintech-muted hover:text-white transition hover:scale-105"><CreditCard size={24} /><span className="text-[10px]">Cards</span></button>
        <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-fintech-accent transition hover:scale-105"><User size={24} /><span className="text-[10px]">Profile</span></button>
      </div>
    </div>
  );
}