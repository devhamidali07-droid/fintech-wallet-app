import React, { useState, useEffect } from 'react';
import { Fingerprint, ShieldCheck } from 'lucide-react';

export default function LoginScreen({ onAuthenticate }) {
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleBiometricLogin = () => {
    setIsAuthenticating(true);
    // Simulate biometric delay
    setTimeout(() => {
      onAuthenticate();
    }, 1500);
  };

  return (
    <div className="flex h-full flex-col items-center justify-between px-6 py-12 text-fintech-text">
      <div className="mt-20 flex flex-col items-center space-y-4 text-center">
        <div className="rounded-2xl bg-fintech-card p-4 shadow-lg ring-1 ring-white/5">
          <ShieldCheck size={48} className="text-fintech-accent" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight">Wallet</h1>
        <p className="text-fintech-muted text-sm">Secure corporate banking portal.</p>
      </div>

      <div className="mb-20 flex w-full flex-col items-center space-y-8">
        <button
          onClick={handleBiometricLogin}
          className={`group relative flex h-24 w-24 items-center justify-center rounded-full transition-all duration-300 ${isAuthenticating ? 'bg-fintech-accent/20 scale-110' : 'bg-fintech-card hover:bg-slate-700'}`}
        >
          <div className={`absolute inset-0 rounded-full border-2 border-fintech-accent/50 ${isAuthenticating ? 'animate-ping' : 'opacity-0'}`}></div>
          <Fingerprint size={40} className={`transition-colors duration-300 ${isAuthenticating ? 'text-fintech-accent' : 'text-fintech-muted group-hover:text-fintech-text'}`} />
        </button>
        <p className="text-sm font-medium text-fintech-muted">
          {isAuthenticating ? 'Verifying Biometrics...' : 'Tap to unlock with Fingerprint'}
        </p>
      </div>
    </div>
  );
}