import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Send, ArrowDownToLine, CreditCard, Home, User, Bell } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

export default function Dashboard({ onNavigate }) {
  const chartData = {
    labels: ['Software/SaaS', 'Cloud Infrastructure', 'Hardware', 'Travel'],
    datasets: [
      {
        data: [45, 25, 20, 10],
        backgroundColor: ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b'],
        borderWidth: 0,
        hoverOffset: 4
      }
    ]
  };

  const chartOptions = {
    cutout: '75%',
    plugins: { legend: { display: false } }
  };

  return (
    <div className="flex min-h-full flex-col px-6 text-fintech-text relative">
      <header className="flex items-center justify-between py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-700 text-sm font-bold">HA</div>
          <div>
            <p className="text-xs text-fintech-muted">Good morning,</p>
            <p className="font-semibold text-sm">Hamid Ali</p>
          </div>
        </div>
        <button className="rounded-full bg-fintech-card p-2 text-fintech-text hover:bg-slate-700"><Bell size={18} /></button>
      </header>

      <div className="mt-4 rounded-3xl bg-gradient-to-br from-fintech-card to-slate-800 p-6 shadow-xl ring-1 ring-white/5">
        <p className="text-sm font-medium text-fintech-muted">Total Balance</p>
        <h2 className="mt-1 text-4xl font-bold tracking-tight text-white">$14,250.00</h2>
        <div className="mt-6 flex justify-between gap-4">
          <button onClick={() => onNavigate('transfer')} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-fintech-accent py-3 text-sm font-bold text-slate-950 hover:bg-emerald-400 transition">
            <Send size={16} /> Send
          </button>
          <button onClick={() => onNavigate('request')} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-slate-700 py-3 text-sm font-bold text-white hover:bg-slate-600 transition">
            <ArrowDownToLine size={16} /> Request
          </button>
        </div>
      </div>

      <div className="mt-8 mb-6">
        <h3 className="text-lg font-semibold text-white">Monthly Breakdown</h3>
        <div className="mt-4 flex items-center justify-between rounded-2xl bg-fintech-card p-5">
          <div className="relative h-28 w-28">
            <Doughnut data={chartData} options={chartOptions} />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-xs text-fintech-muted">Spent</span>
              <span className="text-sm font-bold">$3,240</span>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            {chartData.labels.map((label, i) => (
              <div key={label} className="flex items-center gap-2 text-xs">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: chartData.datasets[0].backgroundColor[i] }}></span>
                <span className="text-fintech-muted">{label}</span>
                <span className="ml-auto font-medium text-white">{chartData.datasets[0].data[i]}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Navigation Navbar */}
      <div className="fixed bottom-[40px] w-[359px] flex justify-around border-t border-slate-800 bg-fintech-dark/95 pb-6 pt-4 backdrop-blur-md z-40 rounded-b-[32px]">
        <button onClick={() => onNavigate('dashboard')} className="flex flex-col items-center gap-1 text-fintech-accent transition hover:scale-105"><Home size={24} /><span className="text-[10px]">Home</span></button>
        <button onClick={() => onNavigate('cards')} className="flex flex-col items-center gap-1 text-fintech-muted hover:text-white transition hover:scale-105"><CreditCard size={24} /><span className="text-[10px]">Cards</span></button>
        <button onClick={() => onNavigate('profile')} className="flex flex-col items-center gap-1 text-fintech-muted hover:text-white transition hover:scale-105"><User size={24} /><span className="text-[10px]">Profile</span></button>
      </div>
    </div>
  );
}