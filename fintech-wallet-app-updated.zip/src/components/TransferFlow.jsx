import React, { useState } from 'react';
import { ChevronLeft, Search, CheckCircle } from 'lucide-react';

export default function TransferFlow({ onBack }) {
  const [step, setStep] = useState(1); // 1: Select Contact, 2: Enter Amount, 3: Success
  const [selectedContact, setSelectedContact] = useState(null);
  const [amount, setAmount] = useState('');

  const contacts = [
    { id: 1, name: 'Fatima Khurram', role: 'Project Collaborator', initials: 'FK', color: 'bg-blue-500' },
    { id: 2, name: 'Ali Hassan', role: 'Digital Media', initials: 'AH', color: 'bg-purple-500' },
    { id: 3, name: 'DevQuest Hosting', role: 'Cloud Services', initials: 'DQ', color: 'bg-orange-500' },
  ];

  const handleContactSelect = (contact) => {
    setSelectedContact(contact);
    setStep(2);
  };

  const handleSend = () => {
    setStep(3);
    setTimeout(() => {
      onBack();
    }, 2500);
  };

  if (step === 3) {
    return (
      <div className="flex h-full flex-col items-center justify-center px-6 text-center text-white">
        <div className="rounded-full bg-fintech-accent/20 p-4">
          <CheckCircle size={64} className="text-fintech-accent" />
        </div>
        <h2 className="mt-6 text-2xl font-bold">Transfer Successful!</h2>
        <p className="mt-2 text-fintech-muted">You sent ${amount} to {selectedContact.name}.</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-full flex-col px-6 text-fintech-text">
      <header className="flex items-center gap-4 py-4">
        <button onClick={step === 1 ? onBack : () => setStep(1)} className="rounded-full bg-fintech-card p-2 text-white hover:bg-slate-700">
          <ChevronLeft size={20} />
        </button>
        <h1 className="text-lg font-semibold">{step === 1 ? 'Send Money' : 'Enter Amount'}</h1>
      </header>

      {step === 1 && (
        <div className="mt-4 animate-in slide-in-from-right text-white">
          <div className="relative mb-6">
            <Search className="absolute left-3 top-3 text-fintech-muted" size={18} />
            <input type="text" placeholder="Search contacts..." className="w-full rounded-xl bg-fintech-card py-3 pl-10 pr-4 text-sm text-white placeholder-fintech-muted outline-none focus:ring-1 focus:ring-fintech-accent" />
          </div>
          
          <h3 className="mb-4 text-xs font-semibold uppercase tracking-wider text-fintech-muted">Recent Collaborators</h3>
          <div className="flex flex-col gap-3">
            {contacts.map(contact => (
              <button key={contact.id} onClick={() => handleContactSelect(contact)} className="flex items-center gap-4 rounded-2xl bg-fintech-card p-4 text-left transition hover:bg-slate-700">
                <div className={`flex h-12 w-12 items-center justify-center rounded-full text-sm font-bold ${contact.color}`}>
                  {contact.initials}
                </div>
                <div>
                  <p className="font-semibold">{contact.name}</p>
                  <p className="text-xs text-fintech-muted">{contact.role}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="mt-8 flex flex-col items-center animate-in slide-in-from-right text-white">
          <div className={`flex h-16 w-16 items-center justify-center rounded-full text-xl font-bold ${selectedContact.color}`}>
            {selectedContact.initials}
          </div>
          <p className="mt-3 font-semibold">{selectedContact.name}</p>
          <p className="text-xs text-fintech-muted">{selectedContact.role}</p>

          <div className="my-12 flex items-center justify-center border-b-2 border-slate-700 pb-2">
            <span className="text-3xl font-bold text-fintech-muted">$</span>
            <input 
              type="number" 
              autoFocus
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-48 bg-transparent text-center text-5xl font-bold text-white outline-none placeholder-slate-700"
            />
          </div>

          <button 
            disabled={!amount || parseFloat(amount) <= 0}
            onClick={handleSend} 
            className="mt-auto w-full rounded-xl bg-fintech-accent py-4 font-bold text-slate-950 transition hover:bg-emerald-400 disabled:opacity-50"
          >
            Confirm Transfer
          </button>
        </div>
      )}
    </div>
  );
}