import React, { useState } from 'react';
import LoginScreen from './components/LoginScreen';
import Dashboard from './components/Dashboard';
import TransferFlow from './components/TransferFlow';
import RequestFlow from './components/RequestFlow';
import CardsScreen from './components/CardsScreen';
import ProfileScreen from './components/ProfileScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('login'); 

  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <LoginScreen onAuthenticate={() => setCurrentScreen('dashboard')} />;
      case 'dashboard':
        return <Dashboard onNavigate={(screen) => setCurrentScreen(screen)} />;
      case 'transfer':
        return <TransferFlow onBack={() => setCurrentScreen('dashboard')} />;
      case 'request':
        return <RequestFlow onBack={() => setCurrentScreen('dashboard')} />;
      case 'cards':
        return <CardsScreen onNavigate={(screen) => setCurrentScreen(screen)} />;
      case 'profile':
        return <ProfileScreen onNavigate={(screen) => setCurrentScreen(screen)} onLogout={() => setCurrentScreen('login')} />;
      default:
        return <LoginScreen onAuthenticate={() => setCurrentScreen('dashboard')} />;
    }
  };

  return (
    <div className="flex h-screen w-full items-center justify-center bg-slate-950 p-4">
      <div className="relative h-[812px] w-[375px] overflow-hidden rounded-[40px] border-[8px] border-slate-800 bg-fintech-dark shadow-2xl ring-1 ring-white/10">
        <div className="absolute left-1/2 top-0 z-50 h-6 w-32 -translate-x-1/2 rounded-b-2xl bg-slate-800"></div>
        <div className="h-full w-full overflow-y-auto overflow-x-hidden pt-8 pb-20">
          {renderScreen()}
        </div>
      </div>
    </div>
  );
}