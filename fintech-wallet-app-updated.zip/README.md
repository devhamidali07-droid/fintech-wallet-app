# FinTech Mobile Banking & Wallet Prototype

This project implements the coded version of the requested FinTech app design system. While Figma is used for designing screens via Auto Layout, this project implements the live, coded equivalent using **React** and **Tailwind CSS Flexbox** (the code equivalent of Auto Layout) to build a fully responsive, mobile-first prototype.

## Key Features Implemented:
1. **Biometric Login Screen:** Simulated fingerprint authentication flow.
2. **Budget Spending Breakdown:** Integrated `react-chartjs-2` to display a sleek, dark-mode pie/doughnut chart of expenses.
3. **Money Transfer User Flow:** Multi-step wizard to search contacts, input amounts, and confirm transfers.
4. **Design System:** Applied a professional, corporate dark-mode FinTech aesthetic using Tailwind's extended color palette.

## How to Run in VS Code

1. Extract the ZIP file and open the folder in **VS Code**.
2. Open the integrated terminal (`Ctrl` + `` ` ``).
3. Install the required packages:
   ```bash
   npm install
   ```
4. Start the Vite development server:
   ```bash
   npm run dev
   ```
5. Click the `http://localhost:5173` link in the terminal to view the interactive mobile prototype.
